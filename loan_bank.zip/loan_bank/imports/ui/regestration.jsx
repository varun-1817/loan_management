import React, { useState } from 'react'
const regestration = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [selectedRoles, setSelectedRoles] = useState([]);
  
   
  
    return (
      <div style={{height:"100%"}}>
        <h2>Registration</h2>
        <form style={{display:"flex",flexDirection:"column",height:"100%"}}>
        <div>
        
          <label>Email:</label>
          <input type="email" onChange={(e) => setEmail(e.target.value)} />
          </div>
           <div>
           <label>Password:</label>
          <input type="password" onChange={(e) => setPassword(e.target.value)} />
            </div>
            <label>Roles:</label>
          <select
          >
            <option value="admin">Admin</option>
            <option value="borrower">Borrower</option>
            <option value="lender">Lender</option>
          </select>
  
        <div>
          </div>
          
          <button type="button" >
            Register
          </button>
        </form>
      </div>
    );
  };
  
  export default regestration;