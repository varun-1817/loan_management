import React, { useState } from 'react'
const regestration = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [selectedRoles, setSelectedRoles] = useState([]);
  
   
  
    return (
      <div>
        <h2>Registration</h2>
        
      </div>
    );
  };
  
  export default regestration;