import React from 'react';
import { Hello } from './Hello.jsx';
import { Info } from './Info.jsx';
import regestration from './regestration.jsx';

export const App = () => (
  
  <div>
    
    <h1>Welcome to Meteor!</h1>
    <form id="registrationForm">
    <label >Email:</label>
    <input type="email" id="email" name="email" required />

    <label>Password:</label>
    <input type="password" id="password" name="password" required />

    <label >Roles:</label>
    <select id="roles" name="roles[]" multiple required>
        <option value="admin">Admin</option>
        <option value="borrower">Borrower</option>
        <option value="lender">Lender</option>
    </select>

    <button type="button" >
        Register
    </button>
</form>


  </div>
);

